################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/Modules/Src/vcp.c 

OBJS += \
./Drivers/Modules/Src/vcp.o 

C_DEPS += \
./Drivers/Modules/Src/vcp.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/Modules/Src/%.o Drivers/Modules/Src/%.su Drivers/Modules/Src/%.cyclo: ../Drivers/Modules/Src/%.c Drivers/Modules/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../USB_DEVICE/App -I"C:/Users/2001082/Session 4/Prog4/Labos/Lab_6/Labo_6_etudiant/Labo_sechs/Drivers/BSP/Inc" -I"C:/Users/2001082/Session 4/Prog4/Labos/Lab_6/Labo_6_etudiant/Labo_sechs/Drivers/Modules/Inc" -I../USB_DEVICE/Target -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-Modules-2f-Src

clean-Drivers-2f-Modules-2f-Src:
	-$(RM) ./Drivers/Modules/Src/vcp.cyclo ./Drivers/Modules/Src/vcp.d ./Drivers/Modules/Src/vcp.o ./Drivers/Modules/Src/vcp.su

.PHONY: clean-Drivers-2f-Modules-2f-Src

