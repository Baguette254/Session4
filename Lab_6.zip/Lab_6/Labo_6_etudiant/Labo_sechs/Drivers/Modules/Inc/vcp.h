/*
 * vcp.h
 *
 *  Created on: 5 févr. 2026
 *      Author: Jonathan Marois
 */

#ifndef MODULES_INC_VCP_H_
#define MODULES_INC_VCP_H_

#include <stdint.h>

uint8_t VCP_IsReady(void);
int8_t VCP_SendStringBlocking(const char *str); // 0=OK, 1=not ready(timeout), 2=tx err/timeout, 3=invalid
void VCP_SendLine(const char *str);

#endif /* MODULES_INC_VCP_H_ */
