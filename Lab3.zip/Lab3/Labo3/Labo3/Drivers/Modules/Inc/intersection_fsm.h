/*
 * intersection_fsm.h
 *
 *  Created on: 10 févr. 2026
 *      Author: Jonathan Marois
 */

#ifndef MODULES_INC_INTERSECTION_FSM_H_
#define MODULES_INC_INTERSECTION_FSM_H_

#include <stdint.h>
#include <stdbool.h>
#include "traffic_light_module.h"

typedef enum {
    IFSM_MODE_NORMAL = 0,
    IFSM_MODE_ALL_RED
} IntersectionMode_t;

typedef struct
{
    /* Feux */
    TrafficLight_t *tl_ns1;   // ex: tl1
    TrafficLight_t *tl_ns2;   // ex: tl3
    TrafficLight_t *tl_ew1;   // ex: tl2
    TrafficLight_t *tl_ew2;   // ex: tl4

    /* Timings (ms) */
    uint32_t t_green;
    uint32_t t_yellow;
    uint32_t t_allred;

    /* État interne */
    uint8_t  state;     // cast vers State_t dans le .c
    uint32_t t_enter;   // timestamp d’entrée dans l’état courant
    IntersectionMode_t mode;

} IntersectionFSM_t;

/* Initialise la FSM et applique l’état initial (NS vert / EW rouge) */
bool IntersectionFSM_Init(IntersectionFSM_t *f,
                          TrafficLight_t *ns1, TrafficLight_t *ns2,
                          TrafficLight_t *ew1, TrafficLight_t *ew2,
                          uint32_t t_green_ms, uint32_t t_yellow_ms, uint32_t t_allred_ms,
                          uint32_t now_ms);

/* Appel périodique (souvent dans while(1)) : FSM non bloquante */
void IntersectionFSM_Tick(IntersectionFSM_t *f, uint32_t now_ms);

/* Force le mode sécurité (tout rouge, FSM gelée) */
void IntersectionFSM_SetAllRed(IntersectionFSM_t *f);

/* Retour au mode normal (repart à NS vert / EW rouge) */
void IntersectionFSM_SetNormal(IntersectionFSM_t *f, uint32_t now_ms);

#endif /* MODULES_INC_INTERSECTION_FSM_H_ */
