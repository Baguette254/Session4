/*
 * traffic_light_module.h
 *
 *  Created on: 4 févr. 2026
 *      Author: Jonathan Marois
 */

#ifndef MODULES_INC_TRAFFIC_LIGHT_MODULE_H_
#define MODULES_INC_TRAFFIC_LIGHT_MODULE_H_

#include <stdint.h>
#include <stdbool.h>
#include "pca9685_driver.h"

typedef enum {
    TL_OFF = 0,
    TL_RED,
    TL_YELLOW,
    TL_GREEN
} TrafficLightColor_t;

typedef struct
{
    PCA9685_Driver_t *pwm;
    uint8_t ch_red;
    uint8_t ch_yellow;
    uint8_t ch_green;
    uint16_t duty_on; // 0..4095
} TrafficLight_t;

bool TrafficLight_Init(TrafficLight_t *tl,
                       PCA9685_Driver_t *pwm,
                       uint8_t ch_r, uint8_t ch_y, uint8_t ch_g,
                       uint16_t duty_on);

bool TrafficLight_Set(TrafficLight_t *tl, TrafficLightColor_t c);


#endif /* MODULES_INC_TRAFFIC_LIGHT_MODULE_H_ */
