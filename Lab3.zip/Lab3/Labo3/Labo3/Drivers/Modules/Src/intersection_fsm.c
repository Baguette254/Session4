/*
 * intersection_fsm.c  (VERSION ÉTUDIANTE)
 *
 *  Labo : Feux de circulation avec FSM non bloquante
 *
 *  Objectif :
 *  - Compléter la machine à états (FSM) pour gérer une intersection.
 *  - Utiliser HAL_GetTick() pour les temporisations (AUCUN HAL_Delay ici).
 *
 *  Mode implémenté :
 *  - IFSM_MODE_NORMAL (obligatoire)
 *  - IFSM_MODE_ALL_RED (fourni)
 */


#include "intersection_fsm.h"

/* États internes de la FSM */
typedef enum {
    ST_NS_GREEN = 0,
    ST_NS_YELLOW,
    ST_ALL_RED_1,
    ST_EW_GREEN,
    ST_EW_YELLOW,
    ST_ALL_RED_2
} State_t;

/* --- Petite fonction utilitaire fournie --- */
static void set_all_red(IntersectionFSM_t *f)
{
    TrafficLight_Set(f->tl_ns1, TL_RED);
    TrafficLight_Set(f->tl_ns2, TL_RED);
    TrafficLight_Set(f->tl_ew1, TL_RED);
    TrafficLight_Set(f->tl_ew2, TL_RED);
}

static void apply_ns_green_ew_red(IntersectionFSM_t *f)
{
	    TrafficLight_Set(f->tl_ns1, TL_GREEN);
	    TrafficLight_Set(f->tl_ns2, TL_GREEN);
	    TrafficLight_Set(f->tl_ew1, TL_RED);
	    TrafficLight_Set(f->tl_ew2, TL_RED);
}

static void apply_ns_yellow_ew_red(IntersectionFSM_t *f)
{
	    TrafficLight_Set(f->tl_ns1, TL_YELLOW);
	    TrafficLight_Set(f->tl_ns2, TL_YELLOW);
	    TrafficLight_Set(f->tl_ew1, TL_RED);
	    TrafficLight_Set(f->tl_ew2, TL_RED);
}

static void apply_ew_green_ns_red(IntersectionFSM_t *f)
{
	    TrafficLight_Set(f->tl_ns1, TL_RED);
	    TrafficLight_Set(f->tl_ns2, TL_RED);
	    TrafficLight_Set(f->tl_ew1, TL_GREEN);
	    TrafficLight_Set(f->tl_ew2, TL_GREEN);
}

static void apply_ew_yellow_ns_red(IntersectionFSM_t *f)
{
	    TrafficLight_Set(f->tl_ns1, TL_RED);
	    TrafficLight_Set(f->tl_ns2, TL_RED);
	    TrafficLight_Set(f->tl_ew1, TL_YELLOW);
	    TrafficLight_Set(f->tl_ew2, TL_YELLOW);
}

/* -----------------------------------------------------------
 * 1) Init
 * -----------------------------------------------------------
 * TODO:
 *  - Initialiser l'état initial (NS vert, EW rouge)
 *  - Initialiser state, t_enter, mode
 */
bool IntersectionFSM_Init(IntersectionFSM_t *f,
                          TrafficLight_t *ns1, TrafficLight_t *ns2,
                          TrafficLight_t *ew1, TrafficLight_t *ew2,
                          uint32_t t_green, uint32_t t_yellow, uint32_t t_allred,
                          uint32_t now_ms)
{
    if (!f || !ns1 || !ns2 || !ew1 || !ew2)
        return false;

    f->tl_ns1 = ns1;
    f->tl_ns2 = ns2;
    f->tl_ew1 = ew1;
    f->tl_ew2 = ew2;

    f->t_green  = t_green;
    f->t_yellow = t_yellow;
    f->t_allred = t_allred;

    // mode initial 
    f->mode = IFSM_MODE_NORMAL;

    // état initial
    f->state = (uint8_t)ST_NS_GREEN;

    // moment d'entrée dans l'état
    f->t_enter = now_ms;

    // TODO: appliquer les sorties correspondant à ST_NS_GREEN
    // NS = VERT, EW = ROUGE
    apply_ns_green_ew_red(f);
    

    return true;
}

/* -----------------------------------------------------------
 * Mode ALL_RED (fourni)
 * ----------------------------------------------------------- */
void IntersectionFSM_SetAllRed(IntersectionFSM_t *f)
{
    if (!f) return;

    f->mode = IFSM_MODE_ALL_RED;
    set_all_red(f);
}

/* -----------------------------------------------------------
 * Retour au mode NORMAL (partiellement fourni)
 * -----------------------------------------------------------
 * TODO:
 *  - Revenir à ST_NS_GREEN et redémarrer le timer
 *  - Appliquer les feux NS=vert, EW=rouge
 */
void IntersectionFSM_SetNormal(IntersectionFSM_t *f, uint32_t now_ms)
{
    if (!f) return;

    f->mode  = IFSM_MODE_NORMAL;
    f->state = (uint8_t)ST_NS_GREEN;
    f->t_enter = now_ms;

    // TODO: réappliquer l'état NS vert / EW rouge
    apply_ns_green_ew_red(f);
}

/* -----------------------------------------------------------
 * 2) Tick (FSM non bloquante)
 * -----------------------------------------------------------
 * Rappel:
 * - On ne bloque jamais
 * - On calcule dt = now - t_enter
 * - Si dt dépasse la durée -> transition + actions + t_enter = now
 *
 * TODO (principal du labo):
 * - Compléter les actions dans chaque transition
 * - Mettre à jour state, t_enter
 */
void IntersectionFSM_Tick(IntersectionFSM_t *f, uint32_t now_ms)
{
    if (!f) return;

    // Mode sécurité : tout rouge (FSM gelée)
    if (f->mode == IFSM_MODE_ALL_RED)
        return;

    uint32_t dt = now_ms - f->t_enter;
    State_t s = (State_t)f->state;

    switch (s)
    {
        case ST_NS_GREEN:
            // TODO:
            // si dt >= t_green -> passer à ST_NS_YELLOW
            // actions: NS = JAUNE, EW = ROUGE
            // mettre à jour f->state et f->t_enter
        	if (dt >= f->t_green)
        	{
        		apply_ns_yellow_ew_red(f);
            // mise à jour de l'état et du timer
        		       f->state  = (uint8_t)ST_NS_YELLOW;
        		       f->t_enter = now_ms;
        	}


            break;

        case ST_NS_YELLOW:
            // TODO:
            // si dt >= t_yellow -> passer à ST_ALL_RED_1
        	if (dt >= f-> t_yellow)
        	{
        		// actions: tous ROUGE
        		set_all_red(f);

        		f->state  = (uint8_t)ST_ALL_RED_1;
        		f->t_enter = now_ms;
        	}

            break;

        case ST_ALL_RED_1:
            // TODO:
            // si dt >= t_allred -> passer à ST_EW_GREEN
            // actions: EW = VERT, NS = ROUGE
        	if (dt >= f-> t_allred)
        	{

        		apply_ew_green_ns_red(f);

        		f->state  = (uint8_t)ST_EW_GREEN;
        		f->t_enter = now_ms;

        	}
            break;

        case ST_EW_GREEN:
            // TODO:
            // si dt >= t_green -> passer à ST_EW_YELLOW
            // actions: EW = JAUNE, NS = ROUGE
        	if (dt >= f-> t_green)
        	{
        		apply_ew_yellow_ns_red(f);


        		f->state  = (uint8_t)ST_EW_YELLOW;
        		f->t_enter = now_ms;

        	}
            break;

        case ST_EW_YELLOW:
            // TODO:
            // si dt >= t_yellow -> passer à ST_ALL_RED_2
            // actions: tous ROUGE
        	if (dt >= f-> t_yellow)
        	{
        		set_all_red(f);


        		f->state  = (uint8_t)ST_ALL_RED_2;
        		f->t_enter = now_ms;
        	}
            break;

        case ST_ALL_RED_2:
            // TODO:
            // si dt >= t_allred -> passer à ST_NS_GREEN
            // actions: NS = VERT, EW = ROUGE
        	if (dt >= f-> t_allred)
        	{
                apply_ns_green_ew_red(f);

                f->state  = (uint8_t)ST_NS_GREEN;
                f->t_enter = now_ms;

        	}
            break;

        default:
            // Sécurité: revenir à un état connu
            f->state = (uint8_t)ST_NS_GREEN;
            f->t_enter = now_ms;

            // TODO: appliquer NS vert / EW rouge
            apply_ns_green_ew_red(f);
            break;
    }
}


