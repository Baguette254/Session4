/*
 * traffic_light_module.c
 *
 *  Created on: 4 févr. 2026
 *      Author: Jonathan Marois
 *
 *  Ce module représente un feu de circulation complet (3 LED : rouge/jaune/verte)
 *  et fournit une API simple :
 *  	-  TrafficLight_Init(...) : associe le feu à 3 canaux du PCA9685
 *  	-  TrafficLight_Set(..., couleur) : met le feu à une couleur (rouge/jaune/vert/off)
 *  👉 Le module ne parle pas I2C directement : il appelle seulement PCA9685_SetDuty().
 */


#include "traffic_light_module.h"

static bool all_off(TrafficLight_t *tl)
{
    if (!PCA9685_SetDuty(tl->pwm, tl->ch_red, 0)) return false;
    if (!PCA9685_SetDuty(tl->pwm, tl->ch_yellow, 0)) return false;
    if (!PCA9685_SetDuty(tl->pwm, tl->ch_green, 0)) return false;
    return true;
}

bool TrafficLight_Init(TrafficLight_t *tl,
                       PCA9685_Driver_t *pwm,
                       uint8_t ch_r, uint8_t ch_y, uint8_t ch_g,
                       uint16_t duty_on)
{
    if (!tl || !pwm) return false;
    if (ch_r > 15 || ch_y > 15 || ch_g > 15) return false;

    tl->pwm = pwm;
    tl->ch_red = ch_r;
    tl->ch_yellow = ch_y;
    tl->ch_green = ch_g;
    tl->duty_on = duty_on;

    return all_off(tl);
}

bool TrafficLight_Set(TrafficLight_t *tl, TrafficLightColor_t c)
{
    if (!tl || !tl->pwm) return false;

    if (!all_off(tl)) return false;

    switch (c)
    {
        case TL_RED:    return PCA9685_SetDuty(tl->pwm, tl->ch_red, tl->duty_on);
        case TL_YELLOW: return PCA9685_SetDuty(tl->pwm, tl->ch_yellow, tl->duty_on);
        case TL_GREEN:  return PCA9685_SetDuty(tl->pwm, tl->ch_green, tl->duty_on);
        case TL_OFF:
        default:        return true;
    }
}
