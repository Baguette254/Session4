/*
 * pca9685_driver.c
 *
 *  Created on: 4 févr. 2026
 *      Author: Jonathan Marois
 */

#include "pca9685_driver.h"

#define PCA9685_MODE1 		0x00
#define PCA9685_MODE2       0x01
#define PCA9685_PRESCALE    0xFE
#define PCA9685_LED0_ON_L   0x06

#define MODE1_RESTART      	(1u << 7)	// Relance/synchronise le PWM (après sortie de SLEEP)
#define MODE1_SLEEP         (1u << 4)	// Arrête l'oscillateur interne (obligatoire pour écrire PRESCALE)
#define MODE1_AI            (1u << 5)	// Auto-increment des registres

#define MODE2_OUTDRV        (1u << 2)	//Push-Pull

#define LED_FULL_BIT  		(1u << 4)  	// bit FULL_ON / FULL_OFF dans ON_H / OFF_H

#define PCA9685_I2C_TIMEOUT_MS  100u

#define PCA9685_ALL_LED_ON_L   0xFA
#define PCA9685_ALL_LED_ON_H   0xFB
#define PCA9685_ALL_LED_OFF_L  0xFC
#define PCA9685_ALL_LED_OFF_H  0xFD



static HAL_StatusTypeDef read8(PCA9685_Driver_t *dev, uint8_t reg, uint8_t *val)
{
    return HAL_I2C_Mem_Read(dev->hi2c, (uint16_t)(dev->addr_7bit << 1),
                            reg, I2C_MEMADD_SIZE_8BIT,
                            val, 1, PCA9685_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef write8(PCA9685_Driver_t *dev, uint8_t reg, uint8_t val)
{
    return HAL_I2C_Mem_Write(dev->hi2c, (uint16_t)(dev->addr_7bit << 1),
                             reg, I2C_MEMADD_SIZE_8BIT,
                             &val, 1, PCA9685_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef writeN(PCA9685_Driver_t *dev, uint8_t reg, const uint8_t *data, uint16_t len)
{
    return HAL_I2C_Mem_Write(dev->hi2c, (uint16_t)(dev->addr_7bit << 1),
                             reg, I2C_MEMADD_SIZE_8BIT,
                             (uint8_t*)data, len, PCA9685_I2C_TIMEOUT_MS);
}


static bool PCA9685_SetPWMCounts(PCA9685_Driver_t *dev, uint8_t ch, uint16_t on, uint16_t off)
{
    if (ch > 15) return false;

    on  &= 0x0FFF;
    off &= 0x0FFF;

    uint8_t reg = (uint8_t)(PCA9685_LED0_ON_L + 4u * ch);
    uint8_t d[4];

    d[0] = (uint8_t)(on & 0xFF);
    d[1] = (uint8_t)((on >> 8) & 0x0F);
    d[2] = (uint8_t)(off & 0xFF);
    d[3] = (uint8_t)((off >> 8) & 0x0F);

    return (writeN(dev, reg, d, 4) == HAL_OK);
}

static bool PCA9685_SetFullOn(PCA9685_Driver_t *dev, uint8_t ch)
{
    if (ch > 15) return false;
    uint8_t reg = (uint8_t)(PCA9685_LED0_ON_L + 4u * ch);
    uint8_t d[4] = { 0x00, LED_FULL_BIT, 0x00, 0x00 };
    return (writeN(dev, reg, d, 4) == HAL_OK);
}

static bool PCA9685_SetFullOff(PCA9685_Driver_t *dev, uint8_t ch)
{
    if (ch > 15) return false;
    uint8_t reg = (uint8_t)(PCA9685_LED0_ON_L + 4u * ch);
    uint8_t d[4] = { 0x00, 0x00, 0x00, LED_FULL_BIT };
    return (writeN(dev, reg, d, 4) == HAL_OK);
}


bool PCA9685_SetDuty(PCA9685_Driver_t *dev, uint8_t channel, uint16_t duty_0_4095)
{
    if (!dev || !dev->hi2c) return false;
    if (channel > 15) return false;

    if (duty_0_4095 >= 4095)
    {
        // LED pleine intensité
        if (dev->active_low) return PCA9685_SetFullOff(dev, channel); // LOW constant
        else                 return PCA9685_SetFullOn(dev, channel);  // HIGH constant
    }

    if (duty_0_4095 == 0)
    {
        // LED éteinte
        if (dev->active_low) return PCA9685_SetFullOn(dev, channel);  // HIGH constant
        else                 return PCA9685_SetFullOff(dev, channel); // LOW constant
    }

    // PWM normal (sans INVRT) : sortie HIGH de on->off
    // active_low : on veut que LED soit ON quand sortie LOW => on inverse le "temps HIGH"
    uint16_t high_time = duty_0_4095;

    if (dev->active_low)
    {
        // LED ON pendant LOW => HIGH_time = 4096 - duty_on
        high_time = (uint16_t)(4096u - duty_0_4095);

        // Clamp sécurité: high_time doit être 1..4095 ici (car duty != 0 et != 4095)
        if (high_time > 4095u) high_time = 4095u;
        if (high_time == 0u)   high_time = 1u;
    }

    // sortie HIGH de 0..high_time, donc LOW le reste
    return PCA9685_SetPWMCounts(dev, channel, 0, high_time);
}

bool PCA9685_AllOff(PCA9685_Driver_t *dev)
{
    if (!dev || !dev->hi2c) return false;

    uint8_t d[4];

    if (dev->active_low)
    {
        // HIGH constant sur tous les canaux => LED OFF (Option A)
        d[0] = 0x00;          // ALL_ON_L
        d[1] = LED_FULL_BIT;  // ALL_ON_H (FULL_ON)
        d[2] = 0x00;          // ALL_OFF_L
        d[3] = 0x00;          // ALL_OFF_H
    }
    else
    {
        // LOW constant sur tous les canaux => OFF (active_high)
        d[0] = 0x00;
        d[1] = 0x00;
        d[2] = 0x00;
        d[3] = LED_FULL_BIT;  // ALL_OFF_H (FULL_OFF)
    }

    return (writeN(dev, PCA9685_ALL_LED_ON_L, d, 4) == HAL_OK);
}


bool PCA9685_Init(PCA9685_Driver_t *dev,
                  I2C_HandleTypeDef *hi2c,
                  uint8_t addr_7bit,
                  uint16_t pwm_freq_hz)
{
    if (!dev || !hi2c) return false;

    dev->hi2c = hi2c;
    dev->addr_7bit = addr_7bit;

    // Valeurs par défaut (robustesse)
    dev->push_pull  = true;
    dev->active_low = true;   // LED ON quand pin LOW

    // 1) MODE1: AI + SLEEP (oscillateur OFF) pour pouvoir écrire PRESCALE
    uint8_t mode1 = 0;
    if (read8(dev, PCA9685_MODE1, &mode1) != HAL_OK) return false;

    // AI=1 et SLEEP=1
    mode1 |= MODE1_AI;
    mode1 |= MODE1_SLEEP;

    if (write8(dev, PCA9685_MODE1, mode1) != HAL_OK) return false;


    // 2) Calcul et écriture du PRESCALE
    if (pwm_freq_hz < 24)   pwm_freq_hz = 24;
    if (pwm_freq_hz > 1526) pwm_freq_hz = 1526;

    uint32_t denom = 4096u * (uint32_t)pwm_freq_hz;
    uint32_t prescale = (25000000u + (denom / 2u)) / denom;
    if (prescale > 0) prescale -= 1;
    if (prescale > 255) prescale = 255;

    if (write8(dev, PCA9685_PRESCALE, (uint8_t)prescale) != HAL_OK) return false;

    // 3) Wake up: SLEEP = 0 (oscillateur ON)
    if (read8(dev, PCA9685_MODE1, &mode1) != HAL_OK) return false;

    mode1 &= (uint8_t)~MODE1_SLEEP;  // SLEEP=0
    mode1 |= MODE1_AI;               // garde AI=1

    if (write8(dev, PCA9685_MODE1, mode1) != HAL_OK) return false;
    HAL_Delay(1);


    // 4) MODE2: config sorties (push-pull/open-drain)
    uint8_t mode2 = 0;
    if (read8(dev, PCA9685_MODE2, &mode2) != HAL_OK) return false;

    if (dev->push_pull) mode2 |= MODE2_OUTDRV;
    else                mode2 &= (uint8_t)~MODE2_OUTDRV;

    if (write8(dev, PCA9685_MODE2, mode2) != HAL_OK) return false;

    // 5) Restart: resynchroniser le PWM
    if (read8(dev, PCA9685_MODE1, &mode1) != HAL_OK) return false;

    mode1 |= MODE1_RESTART;
    mode1 |= MODE1_AI; // (par sécurité)

    if (write8(dev, PCA9685_MODE1, mode1) != HAL_OK) return false;

    return true;
}
