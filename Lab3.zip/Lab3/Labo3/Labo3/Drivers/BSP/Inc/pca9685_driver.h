/*
 * pca9685_driver.h
 *
 *  Created on: 4 févr. 2026
 *      Author: Jonathan Marois
 */

#ifndef BSP_INC_PCA9685_DRIVER_H_
#define BSP_INC_PCA9685_DRIVER_H_

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

typedef struct
{
    I2C_HandleTypeDef *hi2c;
    uint8_t addr_7bit;   // ex: 0x40
    bool push_pull;       // MODE2 OUTDRV (1 = push-pull, 0 = open-drain)
    bool active_low;      // true = LED ON quand sortie LOW
} PCA9685_Driver_t;

bool PCA9685_Init(PCA9685_Driver_t *dev, I2C_HandleTypeDef *hi2c, uint8_t addr_7bit, uint16_t pwm_freq_hz);
bool PCA9685_SetDuty(PCA9685_Driver_t *dev, uint8_t channel, uint16_t duty_0_4095);
bool PCA9685_AllOff(PCA9685_Driver_t *dev);



#endif /* BSP_INC_PCA9685_DRIVER_H_ */
