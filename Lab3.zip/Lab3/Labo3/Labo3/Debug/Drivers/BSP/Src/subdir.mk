################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/BSP/Src/pca9685_driver.c 

OBJS += \
./Drivers/BSP/Src/pca9685_driver.o 

C_DEPS += \
./Drivers/BSP/Src/pca9685_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/BSP/Src/%.o Drivers/BSP/Src/%.su Drivers/BSP/Src/%.cyclo: ../Drivers/BSP/Src/%.c Drivers/BSP/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I"C:/Users/2001082/Session 4/Prog4/Labos/Lab3/Labo3/Labo3/Drivers/BSP/Inc" -I"C:/Users/2001082/Session 4/Prog4/Labos/Lab3/Labo3/Labo3/Drivers/Modules/Inc" -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-BSP-2f-Src

clean-Drivers-2f-BSP-2f-Src:
	-$(RM) ./Drivers/BSP/Src/pca9685_driver.cyclo ./Drivers/BSP/Src/pca9685_driver.d ./Drivers/BSP/Src/pca9685_driver.o ./Drivers/BSP/Src/pca9685_driver.su

.PHONY: clean-Drivers-2f-BSP-2f-Src

